# Workspace and Build System

## Table of contents

1. Workspace layout
2. colcon essentials
3. ament_cmake in depth
4. ament_python and mixed packages
5. package.xml format 3
6. Overlay mechanics
7. Build optimization
8. Dependency management
9. Common failures and fixes

---

## 1. Workspace layout

```text
ros2_ws/
├── src/
│   ├── my_robot_bringup/       # Launch files, top-level config
│   ├── my_robot_description/   # URDF/xacro, meshes
│   ├── my_robot_interfaces/    # msg/srv/action definitions
│   ├── my_robot_driver/        # Hardware driver (C++)
│   ├── my_robot_control/       # Controllers, ros2_control config
│   ├── my_robot_perception/    # Camera/LiDAR processing
│   └── my_robot_navigation/    # Nav2 config and custom plugins
├── build/      # Build artifacts (never commit)
├── install/    # Install space (never commit)
└── log/        # Build and test logs
```

**Why this decomposition matters:**

- Interface packages compile first with zero downstream deps — fast CI iteration
- Description packages are pure data — no code compilation, instant rebuild
- Driver packages isolate hardware deps — other packages stay testable without hardware
- Bringup packages contain only launch and config — change robot configuration without recompiling

### Per-package layout

Typical full layout — include only the entries that apply. Consistency
across a workspace reduces onboarding time and makes CI scripts portable.
Pure `ament_python` packages have `setup.py` instead of `CMakeLists.txt`
and no `include/`; interface-only packages carry little beyond
`package.xml`, `CMakeLists.txt`, and `msg/`/`srv/`/`action/`.

```text
my_package/
├── CMakeLists.txt          # or setup.py for pure Python
├── package.xml             # format 3, with <depend> tags
├── config/
│   └── params.yaml         # default parameters
├── launch/
│   └── bringup.launch.py   # Python launch file
├── include/my_package/     # C++ public headers (if library)
├── src/                    # C++ source files
├── my_package/             # Python modules (if ament_python or mixed)
├── test/                   # gtest, pytest, launch_testing
├── urdf/                   # URDF/xacro (if applicable)
├── msg/ srv/ action/       # custom interfaces (dedicated _interfaces package preferred)
└── README.md
```

Separate interface definitions into a `*_interfaces` package so downstream
packages can depend on interfaces without pulling in implementation.

## 2. colcon essentials

### Build commands

```bash
# Full workspace build
colcon build --symlink-install

# Single package with dependencies
colcon build --packages-up-to my_robot_driver

# Single package only (skip deps, fast iteration)
colcon build --packages-select my_robot_driver

# Release build for deployment
colcon build --cmake-args -DCMAKE_BUILD_TYPE=Release

# Parallel jobs control (useful on resource-limited boards)
colcon build --parallel-workers 2

# Export compile_commands.json for IDE integration
colcon build --cmake-args -DCMAKE_EXPORT_COMPILE_COMMANDS=ON
```

### colcon mixins (speed up repeated builds)

```bash
# Install mixin repo
colcon mixin add default https://raw.githubusercontent.com/colcon/colcon-mixin-repository/master/index.yaml
colcon mixin update default

# Use release mixin
colcon build --mixin release

# Use ccache mixin (dramatically speeds up rebuilds)
colcon build --mixin ccache
```

### Build isolation

colcon builds each package in isolation by default. This means:

- Each package gets its own `build/<pkg>` directory
- CMake cannot accidentally see headers from sibling packages
- Missing `find_package()` or `package.xml` deps break the build immediately (good)

To merge all packages into a single install prefix (not recommended — hides
missing `package.xml` dependencies, but simplifies Docker `PATH`/`LD_LIBRARY_PATH`):

```bash
colcon build --merge-install
```

### Dependency inspection

```bash
# Visualize package dependency graph
colcon graph --dot | dot -Tpng -o deps.png

# Show detailed info about a package
colcon info my_package

# List packages in topological build order
colcon list --topological-order
```

## 3. ament_cmake in depth

### CMake linking: distro comparison

| Feature | Humble (2022.05) | Jazzy (2024.05) | Kilted (2025.05) |
|---|---|---|---|
| `ament_target_dependencies()` | Primary method | Works, but modern CMake preferred | **Deprecated** (emits warning) |
| `target_link_libraries()` with CMake targets | Not available for most ROS pkgs | **Primary method** (`rclcpp::rclcpp`, `${msg_TARGETS}`) | Primary method (same as Jazzy) |
| `${pkg_TARGETS}` for message packages | Not available | Available (`${sensor_msgs_TARGETS}`) | Available |
| `pkg::pkg` for non-message packages | Not available | Available (`rclcpp::rclcpp`) | Available |
| rosbag2 default storage | SQLite3 | MCAP | MCAP |

**Migration path:**

- **Humble → Jazzy**: Replace `ament_target_dependencies(target dep1 dep2)` with `target_link_libraries(target PUBLIC dep1::dep1 ${dep2_TARGETS})`
- **Jazzy → Kilted**: Same syntax; if you haven't migrated yet, the build will now emit deprecation warnings
- **Cross-distro code**: `target_link_libraries()` with modern targets works on Jazzy+ only. For Humble compatibility, keep `ament_target_dependencies()` behind a version guard or maintain separate branches.

### Minimal CMakeLists.txt for a library + node

```cmake
cmake_minimum_required(VERSION 3.8)
project(my_robot_driver)

# Compiler settings
if(CMAKE_COMPILER_IS_GNUCXX OR CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  add_compile_options(-Wall -Wextra -Wpedantic)
endif()

# Dependencies
find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(rclcpp_lifecycle REQUIRED)
find_package(sensor_msgs REQUIRED)
find_package(my_robot_interfaces REQUIRED)

# Library (reusable logic, testable without ROS)
add_library(${PROJECT_NAME}_lib SHARED
  src/driver_core.cpp
  src/serial_transport.cpp
)
target_include_directories(${PROJECT_NAME}_lib PUBLIC
  $<BUILD_INTERFACE:${CMAKE_CURRENT_SOURCE_DIR}/include>
  $<INSTALL_INTERFACE:include/${PROJECT_NAME}>
)
# Modern CMake (Jazzy+ primary, forward-compatible with Kilted)
# Use target_link_libraries with imported CMake targets
target_link_libraries(${PROJECT_NAME}_lib PUBLIC
  rclcpp::rclcpp
  rclcpp_lifecycle::rclcpp_lifecycle
  ${sensor_msgs_TARGETS}
  ${my_robot_interfaces_TARGETS}
)

# ament_target_dependencies() is deprecated in Kilted (2025.05) and must be
# migrated to target_link_libraries() with modern CMake targets as shown above.
# target_link_libraries works on all active distros (Humble+).
# Only fall back to ament_target_dependencies() for deps that lack CMake target exports (rare).

# Executable (thin wrapper around library)
add_executable(driver_node src/driver_node_main.cpp)
target_link_libraries(driver_node ${PROJECT_NAME}_lib)

# Install
install(TARGETS ${PROJECT_NAME}_lib
  EXPORT export_${PROJECT_NAME}
  ARCHIVE DESTINATION lib
  LIBRARY DESTINATION lib
  RUNTIME DESTINATION bin
)
install(TARGETS driver_node DESTINATION lib/${PROJECT_NAME})
install(DIRECTORY include/ DESTINATION include/${PROJECT_NAME})
install(DIRECTORY launch config DESTINATION share/${PROJECT_NAME})

# Testing
if(BUILD_TESTING)
  find_package(ament_lint_auto REQUIRED)
  ament_lint_auto_find_test_dependencies()

  find_package(ament_cmake_gtest REQUIRED)
  ament_add_gtest(test_driver_core test/test_driver_core.cpp)
  target_link_libraries(test_driver_core ${PROJECT_NAME}_lib)
endif()

# Export
ament_export_targets(export_${PROJECT_NAME} HAS_LIBRARY_TARGET)
ament_export_dependencies(rclcpp rclcpp_lifecycle sensor_msgs my_robot_interfaces)
ament_package()
```

**Note**: For message packages, use `${package_TARGETS}` (e.g., `${sensor_msgs_TARGETS}`) which expands to the correct CMake target names. For non-message packages, use the `package::package` syntax (e.g., `rclcpp::rclcpp`).

### Component registration (for composition)

```cmake
# In addition to the above, register as a composable node
find_package(rclcpp_components REQUIRED)

add_library(driver_component SHARED src/driver_component.cpp)
target_link_libraries(driver_component
  ${PROJECT_NAME}_lib
  rclcpp::rclcpp
  rclcpp_components::component
)
# NOTE: ament_target_dependencies() is deprecated in Kilted (2025.05) and will
# be removed in a future distro. Migrate to target_link_libraries() with modern
# CMake targets (e.g. rclcpp::rclcpp) as shown above.

rclcpp_components_register_nodes(driver_component "my_robot_driver::DriverComponent")

install(TARGETS driver_component
  ARCHIVE DESTINATION lib
  LIBRARY DESTINATION lib
  RUNTIME DESTINATION bin
)
```

### Interface package CMakeLists.txt

```cmake
cmake_minimum_required(VERSION 3.8)
project(my_robot_interfaces)

find_package(ament_cmake REQUIRED)
find_package(rosidl_default_generators REQUIRED)
find_package(geometry_msgs REQUIRED)
find_package(std_msgs REQUIRED)

rosidl_generate_interfaces(${PROJECT_NAME}
  "msg/RobotStatus.msg"
  "msg/SensorData.msg"
  "srv/SetMode.srv"
  "action/MoveToPosition.action"
  DEPENDENCIES geometry_msgs std_msgs
)

ament_export_dependencies(rosidl_default_runtime)
ament_package()
```

## 4. ament_python and mixed packages

### Pure Python package (setup.py)

```python
from setuptools import find_packages, setup

package_name = 'my_robot_monitor'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/monitor.launch.py']),
        ('share/' + package_name + '/config', ['config/params.yaml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    entry_points={
        'console_scripts': [
            'monitor_node = my_robot_monitor.monitor_node:main',
        ],
    },
)
```

### Mixed C++/Python package (ament_cmake_python)

Use `ament_cmake` as the build type but add Python module installation:

```cmake
find_package(ament_cmake_python REQUIRED)
ament_python_install_package(${PROJECT_NAME})
```

This is the correct approach when you need both a C++ library and Python bindings
or utilities in the same package.

## 5. package.xml format 3

```xml
<?xml version="1.0"?>
<?xml-model href="http://download.ros.org/schema/package_format3.xsd"
  schematypens="http://www.w3.org/2001/XMLSchema"?>
<package format="3">
  <name>my_robot_driver</name>
  <version>0.1.0</version>
  <description>Hardware driver for My Robot</description>
  <maintainer email="you@example.com">Your Name</maintainer>
  <license>Apache-2.0</license>

  <buildtool_depend>ament_cmake</buildtool_depend>

  <!-- Prefer <depend> when used at both build and runtime -->
  <depend>rclcpp</depend>
  <depend>rclcpp_lifecycle</depend>
  <depend>sensor_msgs</depend>
  <depend>my_robot_interfaces</depend>

  <!-- Needed at build and runtime (component container loads the shared lib) -->
  <depend>rclcpp_components</depend>

  <!-- Test deps -->
  <test_depend>ament_lint_auto</test_depend>
  <test_depend>ament_lint_common</test_depend>
  <test_depend>ament_cmake_gtest</test_depend>

  <export>
    <build_type>ament_cmake</build_type>
  </export>
</package>
```

**`<depend>` vs `<build_depend>` vs `<exec_depend>`:**

- `<depend>` = build + exec (most common, use by default)
- `<build_depend>` = headers/libraries needed only at compile time
- `<exec_depend>` = needed at runtime only (e.g. launch file deps)
- `<test_depend>` = needed only for testing

## 6. Overlay mechanics

ROS 2 workspaces form a chain of overlays:

```text
/opt/ros/jazzy/          ← underlay (system install)
  └── ~/ros2_ws/install/  ← overlay (your workspace)
       └── ~/dev_ws/install/ ← overlay (experimental)
```

**Rules:**

- Source underlays before building the overlay
- A package in the overlay shadows the same package in the underlay
- `colcon build --symlink-install` creates symlinks to source files,
  so Python edits take effect without rebuilding
- C++ changes always require a rebuild

**Overlay order is resolution order.** `AMENT_PREFIX_PATH` decides which copy of
a package a process actually loads, and the first prefix containing it wins.
A forgotten workspace earlier in that list shadows the one you are editing, and
`install/` keeps artifacts of sources you have deleted — colcon does not remove
them. When a rebuild appears to have no effect, audit the running process
instead of rebuilding again: `references/runtime-provenance.md` ("What the
running process actually inherited", "Source tree vs installed copy").

**Multiple workspace pattern for large teams:**

```bash
# Team-shared stable workspace
source /opt/ros/jazzy/setup.bash
cd ~/team_ws && colcon build
source ~/team_ws/install/setup.bash

# Personal development workspace (overlays team_ws)
cd ~/dev_ws && colcon build
source ~/dev_ws/install/setup.bash
```

## 7. Build optimization

### ccache (10x faster rebuilds)

```bash
sudo apt install ccache
# Add to ~/.bashrc
export CC="ccache gcc"
export CXX="ccache g++"

# Or use colcon mixin
colcon build --mixin ccache
```

### Parallel linking (saves memory on ARM boards)

```bash
# Limit parallel link jobs (linking is memory-heavy)
# Use --parallel-workers to reduce package-level parallelism
colcon build --parallel-workers 2
# Or set MAKEFLAGS to limit make-level parallelism
MAKEFLAGS="-j2" colcon build
```

### Selective builds in CI

```bash
# Only build packages that contain changed files (and their dependents)
CHANGED_DIRS=$(git diff --name-only HEAD~1 | xargs -I{} dirname {} | sort -u)
CHANGED_PKGS=$(colcon list -n --base-paths $CHANGED_DIRS 2>/dev/null | tr '\n' ' ')
if [ -n "$CHANGED_PKGS" ]; then
  colcon build --packages-above $CHANGED_PKGS
fi
```

### 7.4 Performance Benchmarking Tools

When optimizing a ROS 2 workspace, guessing where the bottlenecks are is a mistake. Use proper benchmarking tools.

**1. `performance_test` (Apex.AI)**
The standard tool for profiling DDS middleware latency, jitter, and throughput. It tests the raw transport layer without your application logic.

```bash
# Build the tool
sudo apt install ros-jazzy-performance-test
# Run a 10-minute test: 1 publisher, 1 subscriber, 1KB message at 1000Hz using CycloneDDS
ros2 run performance_test perf_test -c CycloneDDS -m Array1k -r 1000 -p 1 -s 1 --max_runtime 600
```

*Metrics to watch:* Look at the `T_lat` (latency) and `jitter` columns. If your $99.99^{th}$ percentile latency is high, your network stack or CPU governor needs tuning.

**2. `ros2_tracing` (LTTng)**

The ultimate tool for pipeline latency. It profiles the exact microseconds it takes for your message to go from the UDP socket into your callback.

```bash
sudo apt install ros-jazzy-ros2trace ros-jazzy-tracetools-launch
# Start tracing with full ROS 2 instrumentation
ros2 trace start my_trace
# Run your nodes...
ros2 trace stop
```

*Analysis:* Use the `tracetools_analysis` Jupyter notebooks to generate flame graphs and callback duration histograms.

**3. `ros2 topic delay` and `ros2 topic hz`**

Quick CLI checks for end-to-end latency and frequency drops.

```bash
# Requires the publisher to populate the std_msgs/Header.stamp field!
ros2 topic delay /camera/image_raw
```

## 8. Dependency management

### rosdep

```bash
# Install all dependencies for workspace
cd ~/ros2_ws
rosdep install --from-paths src --ignore-src -y

# Check what would be installed
rosdep install --from-paths src --ignore-src --simulate
```

### Custom rosdep keys

Create `rosdep.yaml` for packages not in the official database:

```yaml
my_custom_lib:
  ubuntu:
    pip:
      packages: [my-custom-lib]
```

Register it:

```bash
echo "yaml file://$(pwd)/rosdep.yaml" | sudo tee /etc/ros/rosdep/sources.list.d/50-custom.list
rosdep update
```

### vcstool for multi-repo workspaces

```yaml
# repos.yaml
repositories:
  my_robot_driver:
    type: git
    url: https://github.com/org/my_robot_driver.git
    version: jazzy
  my_robot_interfaces:
    type: git
    url: https://github.com/org/my_robot_interfaces.git
    version: jazzy
```

```bash
vcs import src < repos.yaml   # clones into src/my_robot_driver, src/my_robot_interfaces
vcs pull src
```

## 9. Common failures and fixes

| Symptom | Cause | Fix |
|---|---|---|
| `Could not find package X` in CMake | Missing `find_package()` or `package.xml` dep | Add both `find_package(X REQUIRED)` and `<depend>X</depend>` |
| Header not found despite package installed | Missing `target_include_directories` or `target_link_libraries` | Use `target_link_libraries` with modern CMake targets (e.g. `rclcpp::rclcpp`), which handles include paths automatically. `ament_target_dependencies` is deprecated in Kilted (2025.05). |
| `setup.py` changes not reflected | Built without `--symlink-install` | Rebuild with `colcon build --symlink-install` |
| "Package not found" after build | Forgot to source `install/setup.bash` | Source after every build, or use `direnv` |
| Circular dependency error | Package A depends on B and B depends on A | Extract shared interfaces into a third package |
| "Multiple packages with name X" | Duplicate package in overlay and underlay | Remove the underlay version or use `--packages-select` |
| Rebuild has no effect on the running node | Another overlay shadows the package, or `install/` still holds a deleted source's artifacts | Audit the process's `AMENT_PREFIX_PATH` and installed files (`references/runtime-provenance.md`); delete `build/`/`install/`/`log/` for that package and rebuild |
| Link error: undefined reference | Library not listed in `target_link_libraries` | Add library to CMake target linking |

---

**See also:** `references/testing.md` for colcon test integration and CI/CD patterns, `references/deployment.md` for Docker multi-stage builds and cross-compilation, `references/launch-system.md` for package discovery and launch file installation.
