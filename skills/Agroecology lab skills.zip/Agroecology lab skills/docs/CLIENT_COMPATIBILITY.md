# Client compatibility and installation

Reviewed against the primary sources below on 2026-09-07. A documented client
feature is not a recorded successful run of this repository on that client.

## Two different products

The portable skill is `SKILL.md`, references, scripts, and optional client
metadata. The Claude Code plugin additionally registers session hooks. Copying
a full checkout into a skill directory is not necessarily knowledge-only:
Claude Code recognizes `.claude-plugin/plugin.json` there as a plugin after
applicable trust checks. Use the copy installer below for an intentionally
hook-free installation. It never changes settings or tool permissions.

```bash
python3 -m pip install -r requirements.txt
python3 scripts/install_skill.py --client codex --dry-run
python3 scripts/install_skill.py --client codex
python3 scripts/install_skill.py --client claude --project /path/to/project
python3 scripts/install_skill.py --client cursor
python3 scripts/install_skill.py --client gemini
```

All commands start in a trusted checkout. Use a virtual environment when the
host Python requires one. Python 3.10+ and PyYAML are required by this installer.
On Windows use `py -3` instead of `python3` where appropriate. Existing targets
need `--force`; replacement is staged and validated before the old skill moves.
`--target` names the complete final skill directory, not its parent. Nested
symlinks and replacing arbitrary non-skill directories are deliberately refused.
The legacy `install.sh` and `install.ps1` remain full-checkout copy/link tools.
Portable installs are serialized with a sibling `.ros2-engineering-skills.install-lock`
directory. After an interrupted process, remove that lock only after confirming
no installer is still running. If replacement and rollback both fail, the error
identifies a `.skill-backup-*/previous` directory containing the old installation;
it is deliberately not automatically deleted. A `backup_retained` field on a
successful result means old-backup cleanup failed, not that installation failed.

## Discovery and explicit invocation

| Client | Personal installation | Project installation | Explicit invocation |
|---|---|---|---|
| Claude Code, knowledge-only | `~/.claude/skills/ros2-engineering-skills` | `.claude/skills/ros2-engineering-skills` | `/ros2-engineering-skills` |
| Claude Code, plugin | Client-managed plugin cache | Client-managed plugin scope | `/ros2-engineering:ros2-engineering-skills` |
| Codex CLI / IDE | `~/.agents/skills/ros2-engineering-skills` | `.agents/skills/ros2-engineering-skills` | `$ros2-engineering-skills`; inspect `/skills` |
| Cursor | `~/.cursor/skills/ros2-engineering-skills` | `.cursor/skills/ros2-engineering-skills` | Select the skill from the slash menu |
| Gemini CLI | `~/.gemini/skills/ros2-engineering-skills` | `.gemini/skills/ros2-engineering-skills` | Inspect `/skills list`; request the skill explicitly |

The shared `.agents/skills` directory is also documented by Cursor and Gemini.
Gemini gives `.agents` precedence over `.gemini` within the same scope. Avoid
multiple copies with the same name; inspect the resolved path, not just the name.
Codex discovers project skills along the path from the working directory to the
repository root. Host policies and trust settings can still disable discovery.

Cursor's personal skills are not automatically copied to every remote/cloud
execution environment. A skill installed on a laptop is not proof that a remote
agent sees it. Install or commit the project-scoped bundle in the actual execution
environment, and capture the selected path and revision there.

## Claude Code plugin

```bash
claude plugin marketplace add dbwls99706/ros2-engineering-skills
claude plugin install ros2-engineering@ros2-engineering-skills
claude plugin validate . --strict
claude --plugin-dir . plugin details ros2-engineering@inline
```

Run the last two commands from a trusted checkout for local development, not as
proof that every marketplace cache is current. CI pins the tested client version;
newer client behavior needs a separate recorded check. This repository uses the
supported root `SKILL.md` discovery path, not a duplicated nested copy. Hooks stay
in `hooks/hooks.json`, outside portable frontmatter. After editing plugin hooks,
reload plugins or restart the client. Skill-text live reload is a different path.

The plugin matcher registers PreToolUse and advisory Stop. `Bash` is the primary
shell tool; extra matcher names are compatibility aliases, not a claim that every
client exposes PowerShell or `cmd` as a native tool. A working `python3` command
is required by this hook configuration. A Windows copy-installer test does not
establish Windows hook interpreter availability.

## Codex metadata and permission boundary

`agents/openai.yaml` supplies a display name, short description, explicit default
prompt, and `policy.allow_implicit_invocation: true`. This advertises the skill;
it does not grant shell, network, hardware, or write access. Explicit invocation
and automatic selection must be evaluated separately. This repository does not
ship a Codex hook adapter: use the portable validators manually. Do not rename
Claude's hook JSON and assume that another client's event protocol is identical.

## Model upgrades: share intent, not client settings

The invocation and permission comparison here was reviewed on 2026-09-09 against
[Codex skills](https://learn.chatgpt.com/docs/build-skills) and
[Claude Code skills](https://code.claude.com/docs/en/skills). It is not a claim that
any new model has passed this bundle's behavioral scenarios.

| Concern | Claude Code | Codex | This bundle's choice |
|---|---|---|---|
| Automatic selection | `disable-model-invocation: true` disables automatic loading | `policy.allow_implicit_invocation: false` in `agents/openai.yaml` disables implicit use | Keep domain-based discovery enabled; invocation is not permission to actuate |
| Tool approval | `allowed-tools` pre-approves listed tools; it is not a sandbox or a denylist | Invocation policy does not configure sandbox or approval settings | No tool pre-approval in shared frontmatter; retain the active client's permissions |
| Model and execution context | `model`, `effort`, and `context: fork` are client-specific controls | Do not translate those fields into Codex settings by name | Inherit the user's selected model/context; no forced subagent or effort override |

Keep portable ROS constraints in `SKILL.md`; client-specific integration belongs
in that client's metadata and adapters. Do not copy Claude permission grants,
hook payloads, or fork controls into Codex, or treat Codex's invocation policy as
Claude configuration. A model upgrade does not authorize changing `AGENTS.md`,
`CLAUDE.md`, global settings, CI gates, or physical execution permissions.

Keep the ROS use case first in the description. Codex can shorten descriptions
in a crowded discovery list; Claude also limits listing text. Neither behavior
justifies an unconditional "always use this skill" rule or preloading every
reference. Use fresh positive, negative, and explicit-invocation sessions with
the exact client/model and competing skills. Compare task completion, incorrect
claims, unnecessary reads/tool calls, and available cost data with the skill off
and with the prior revision. Follow [EVIDENCE_CAPTURE.md](EVIDENCE_CAPTURE.md);
lexical fixtures and discovery checks are not model-quality measurements.

## Acceptance procedure

For each exact client version, test a fresh positive implicit prompt, a fresh
negative prompt, and explicit invocation. Use `evals/trigger_cases.json`. Record
whether the skill was selected, the resolved path/revision, which references were
opened, and any actual tool calls. A skill mentioning its own name in an answer
is not loading evidence. Test hooks independently with known transport payloads;
then test a real client event. Do not compare a warmed-up skill-on session with
an unrelated or contaminated control session.

CI verifies the pinned Claude plugin's structure and component discovery, Python
adapter behavior, and portable installation layout. Authenticated end-to-end
model runs for all clients are a separate evidence requirement; see
[EVIDENCE_CAPTURE.md](EVIDENCE_CAPTURE.md). No cross-client model benchmark is
claimed merely because these package and protocol tests pass.

## Automated discovery probes

`client-discovery.yml` installs pinned Codex 0.153.4 and Gemini CLI 0.58.0 in
CI. Each uses an isolated home and workspace, checks absence before installation,
then requires the enabled skill at the exact installed location. Codex is queried
through the documented app-server `initialize` / `initialized` / `skills/list`
protocol; Gemini uses `gemini skills list`. The job records client versions and
before/after output as a workflow artifact. It starts no model turn, supplies no
API credentials, and makes no answer-quality or implicit-trigger claim. A parser
unit test is separate from these live client checks. Read the job's result before
calling a particular revision's discovery verified.

The app-server reference describes optional `SKILL.json` metadata while the
skill-authoring guide documents `agents/openai.yaml`. This repository follows the
authoring guide; the discovery gate checks the portable name, description, enabled
state, and resolved path, without assuming every UI field has identical handling
across clients. Review the exact client version before asserting UI behavior.

Sources: [Codex app-server protocol](https://learn.chatgpt.com/docs/app-server)
and [Gemini CLI skill listing implementation](https://github.com/google-gemini/gemini-cli/blob/v0.58.0/packages/cli/src/commands/skills/list.ts).

## Primary sources

- [Agent Skills specification](https://agentskills.io/specification)
- [Claude Code skills](https://code.claude.com/docs/en/skills)
- [Claude plugin reference](https://code.claude.com/docs/en/plugins-reference)
- [Claude hooks reference](https://code.claude.com/docs/en/hooks)
- [OpenAI skill authoring and Codex installation](https://learn.chatgpt.com/docs/build-skills)
- [Cursor skills](https://cursor.com/docs/skills)
- [Gemini CLI skills](https://geminicli.com/docs/cli/skills/)
