-- odrive_can_drive.lua
-- Drives two ODrive v3.5 axes (firmware 0.5.x, CAN Simple) from the ArduPilot Rover
-- skid-steer throttle outputs (SERVOx_FUNCTION 73 ThrottleLeft / 74 ThrottleRight).
--
-- Structure follows ArduPilot's CAN_write.lua and CAN_MiniCheetah_drive.lua examples
-- (ArduPilot is GPLv3, so treat this file as GPLv3 too).
--
-- Needs: SCR_ENABLE=1, CAN_P1_DRIVER=1, CAN_P1_BITRATE=250000, CAN_D1_PROTOCOL=10.
-- Not for anything safety-rated. If this script stops, only the ODrive watchdog
-- (axis.config.enable_watchdog) will stop the motors.

---@diagnostic disable: need-check-nil
---@diagnostic disable: param-type-mismatch

-- ===== settings =====
local NODES = {
  -- id   = ODrive axis config.can.node_id
  -- func = ArduPilot SERVOx_FUNCTION value to follow
  -- sign = 1 or -1, flips the direction of that side
  { id = 0, func = 73, sign =  1, name = "left"  },
  { id = 1, func = 74, sign = -1, name = "right" },
}
local MAX_RPS     = 2.0    -- motor turns/s at full throttle. Keep low for first tests.
local ACCEL_RPS2  = 5.0    -- slew limit, turns/s per second
local UPDATE_MS   = 20     -- 50 Hz; must be well inside the ODrive watchdog timeout
local BUFFER_SIZE = 20
local HB_TIMEOUT_TICKS  = 50    -- 1 s without a heartbeat counts as lost
local WARN_INTERVAL     = 250   -- ticks between repeats of the same warning (5 s)
local STOP_REPEATS      = 5     -- zero-velocity + idle frames sent after disarm
-- ====================

-- ODrive CAN Simple command IDs (0.5.x)
local CMD_HEARTBEAT        = 0x01
local CMD_SET_AXIS_STATE   = 0x07
local CMD_SET_CTRL_MODES   = 0x0B
local CMD_SET_INPUT_VEL    = 0x0D
local CMD_CLEAR_ERRORS     = 0x18

local STATE_IDLE           = 1
local STATE_CLOSED_LOOP    = 8
local CTRL_MODE_VELOCITY   = 2
local INPUT_MODE_PASSTHRU  = 1

local driver = CAN:get_device(BUFFER_SIZE)
if not driver then
  gcs:send_text(3, "ODrive: no scripting CAN driver (check CAN_P1_DRIVER, CAN_D1_PROTOCOL=10)")
  return
end

local tick = 0
local engaged = false
local latched = false
local stop_count = 0
local last_warn = {}
local cur = {}      -- current commanded turns/s per node id
local hb = {}       -- last heartbeat per node id

for _, n in ipairs(NODES) do
  cur[n.id] = 0.0
  hb[n.id] = { err = 0, state = 0, seen = nil }
end

local function warn(key, text)
  local last = last_warn[key]
  if last == nil or (tick - last) >= WARN_INTERVAL then
    gcs:send_text(4, text)
    last_warn[key] = tick
  end
end

-- standard 11-bit frame: (node_id << 5) | cmd_id, little-endian payload
local function send(node_id, cmd, payload)
  local msg = CANFrame()
  msg:id(uint32_t((node_id << 5) | cmd))
  for i = 1, #payload do
    msg:data(i - 1, payload:byte(i))
  end
  msg:dlc(#payload)
  local ok = driver:write_frame(msg, 10000)
  if not ok then
    warn("tx", "ODrive: CAN write failed")
  end
  return ok
end

local function send_vel(node_id, turns_per_s)
  send(node_id, CMD_SET_INPUT_VEL, string.pack("<ff", turns_per_s, 0.0))
end

local function send_state(node_id, state)
  send(node_id, CMD_SET_AXIS_STATE, string.pack("<I4", state))
end

-- read whatever is waiting and keep the latest heartbeat for each node
local function poll()
  for _ = 1, 16 do
    local frame = driver:read_frame()
    if not frame then
      return
    end
    local id = frame:id():toint()
    if id <= 0x7FF and (id & 0x1F) == CMD_HEARTBEAT then
      local node_id = id >> 5
      local entry = hb[node_id]
      if entry then
        entry.err = frame:data(0) | (frame:data(1) << 8) | (frame:data(2) << 16) | (frame:data(3) << 24)
        entry.state = frame:data(4)
        entry.seen = tick
      end
    end
  end
end

local function alive(node_id)
  local seen = hb[node_id].seen
  return seen ~= nil and (tick - seen) <= HB_TIMEOUT_TICKS
end

local function clamp(x, lo, hi)
  if x < lo then return lo end
  if x > hi then return hi end
  return x
end

local function engage()
  for _, n in ipairs(NODES) do
    send(n.id, CMD_SET_CTRL_MODES, string.pack("<i4i4", CTRL_MODE_VELOCITY, INPUT_MODE_PASSTHRU))
    send_vel(n.id, 0.0)
    send_state(n.id, STATE_CLOSED_LOOP)
    cur[n.id] = 0.0
  end
  engaged = true
  latched = false
  gcs:send_text(6, "ODrive: closed loop requested")
end

local function update()
  tick = tick + 1
  poll()

  -- disarmed: make sure the axes end up idle
  if not arming:is_armed() then
    if engaged then
      engaged = false
      stop_count = STOP_REPEATS
    end
    if stop_count > 0 then
      for _, n in ipairs(NODES) do
        cur[n.id] = 0.0
        send_vel(n.id, 0.0)
        send_state(n.id, STATE_IDLE)
      end
      stop_count = stop_count - 1
    end
    return
  end

  -- armed but not yet driving: wait for every node, clear old errors, then engage
  if not engaged then
    for _, n in ipairs(NODES) do
      if not alive(n.id) then
        warn("hb" .. n.id, string.format("ODrive: no heartbeat from node %d (%s)", n.id, n.name))
        return
      end
    end
    for _, n in ipairs(NODES) do
      if hb[n.id].err ~= 0 then
        warn("clr" .. n.id, string.format("ODrive: node %d error 0x%X, clearing", n.id, hb[n.id].err))
        send(n.id, CMD_CLEAR_ERRORS, string.pack("<B", 0))
        return
      end
    end
    engage()
    return
  end

  -- driving: any axis error stops both sides until the next disarm/arm
  if not latched then
    for _, n in ipairs(NODES) do
      if hb[n.id].err ~= 0 then
        latched = true
        gcs:send_text(3, string.format("ODrive: node %d error 0x%X, stopping both axes", n.id, hb[n.id].err))
        break
      end
      if not alive(n.id) then
        latched = true
        gcs:send_text(3, string.format("ODrive: lost heartbeat from node %d, stopping both axes", n.id))
        break
      end
    end
  end

  local step = ACCEL_RPS2 * (UPDATE_MS / 1000.0)
  for _, n in ipairs(NODES) do
    local target = 0.0
    if not latched then
      local out = SRV_Channels:get_output_scaled(n.func) or 0
      target = clamp(out / 1000.0, -1.0, 1.0) * MAX_RPS * n.sign
    end
    local delta = clamp(target - cur[n.id], -step, step)
    cur[n.id] = cur[n.id] + delta
    send_vel(n.id, cur[n.id])
  end
end

-- a Lua error would otherwise end the script silently, so report it and keep going
local function protected_wrapper()
  local ok, err = pcall(update)
  if not ok then
    gcs:send_text(0, "ODrive script error: " .. tostring(err))
    return protected_wrapper, 1000
  end
  return protected_wrapper, UPDATE_MS
end

gcs:send_text(6, "ODrive CAN drive script loaded")
return protected_wrapper, 1000
