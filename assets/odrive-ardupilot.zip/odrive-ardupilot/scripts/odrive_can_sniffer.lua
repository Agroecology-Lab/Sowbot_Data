-- odrive_can_sniffer.lua
-- Bench check before driving anything: lists ODrive heartbeats seen on the scripting CAN bus.
-- Based on ArduPilot's CAN_read.lua example (GPLv3). Run it on its own, not alongside
-- odrive_can_drive.lua.
--
-- Heartbeat (cmd 0x01): bytes 0-3 axis error (uint32 LE), byte 4 axis state.

---@diagnostic disable: need-check-nil

local driver = CAN:get_device(20)
if not driver then
  gcs:send_text(3, "ODrive sniffer: no scripting CAN driver (check CAN_P1_DRIVER, CAN_D1_PROTOCOL=10)")
  return
end

local REPORT_TICKS = 100   -- 100 x 10 ms = 1 s
local tick = 0
local seen = {}
local other = 0

local function update()
  tick = tick + 1
  for _ = 1, 32 do
    local frame = driver:read_frame()
    if not frame then break end
    local id = frame:id():toint()
    if id <= 0x7FF and (id & 0x1F) == 0x01 then
      seen[id >> 5] = {
        err = frame:data(0) | (frame:data(1) << 8) | (frame:data(2) << 16) | (frame:data(3) << 24),
        state = frame:data(4),
      }
    else
      other = other + 1
    end
  end

  if tick % REPORT_TICKS == 0 then
    local any = false
    for node_id, hb in pairs(seen) do
      any = true
      gcs:send_text(6, string.format("ODrive node %d: state %d, error 0x%X", node_id, hb.state, hb.err))
    end
    if not any then
      gcs:send_text(6, string.format("ODrive sniffer: no heartbeats (%d other frames)", other))
    end
    seen = {}
  end
  return update, 10
end

return update, 1000
