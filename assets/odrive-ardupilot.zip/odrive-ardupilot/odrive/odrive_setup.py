#!/usr/bin/env python3
"""Set CAN node IDs, bit rate, heartbeat and watchdog on an ODrive v3.5 (firmware 0.5.x).

    pip install odrive
    python3 odrive_setup.py            # defaults: nodes 0/1, 250 kbit/s, 0.5 s watchdog

Motor and encoder calibration are not touched. Do those first, with odrivetool, and set
pre_calibrated so closed loop can be entered without a calibration sequence.
Attribute names changed between 0.5.x releases, so this tries both spellings.
"""
import argparse
import sys

import odrive


def set_first(obj, names, value):
    """Set the first attribute name that exists on obj."""
    for name in names:
        parent = obj
        parts = name.split(".")
        try:
            for part in parts[:-1]:
                parent = getattr(parent, part)
            getattr(parent, parts[-1])  # raises if missing
        except AttributeError:
            continue
        setattr(parent, parts[-1], value)
        return name
    raise SystemExit(f"None of {names} exist on this firmware; check with tab-completion in odrivetool.")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--node0", type=int, default=0)
    p.add_argument("--node1", type=int, default=1)
    p.add_argument("--baud", type=int, default=250000)
    p.add_argument("--heartbeat-ms", type=int, default=100)
    p.add_argument("--watchdog-s", type=float, default=0.5)
    p.add_argument("--no-watchdog", action="store_true")
    args = p.parse_args()

    print("Looking for an ODrive...")
    odrv = odrive.find_any()
    print("Found", hex(odrv.serial_number), "firmware",
          f"{odrv.fw_version_major}.{odrv.fw_version_minor}.{odrv.fw_version_revision}")

    set_first(odrv, ["can.config.baud_rate", "config.can_baud_rate"], args.baud)

    for axis, node in ((odrv.axis0, args.node0), (odrv.axis1, args.node1)):
        set_first(axis, ["config.can.node_id", "config.can_node_id"], node)
        set_first(axis, ["config.can.heartbeat_rate_ms", "config.can_heartbeat_rate_ms"], args.heartbeat_ms)
        if not args.no_watchdog:
            set_first(axis, ["config.watchdog_timeout"], args.watchdog_s)
            set_first(axis, ["config.enable_watchdog"], True)
        axis.controller.config.control_mode = 2   # velocity control
        axis.controller.config.input_mode = 1     # passthrough

    print("Saving (the ODrive reboots)...")
    try:
        odrv.save_configuration()
    except Exception:
        pass  # the USB connection drops on reboot
    print("Done. Fit the 120 ohm CAN termination jumper if this ODrive is at the end of the bus.")


if __name__ == "__main__":
    sys.exit(main())
