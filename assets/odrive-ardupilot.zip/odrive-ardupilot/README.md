# ODrive v3.5 over CAN from ArduPilot Rover

Lua scripts that drive two ODrive axes (left and right of a skid-steer rover) from ArduPilot's
throttle outputs, using ODrive's CAN Simple protocol (firmware 0.5.x).

## Contents

| File | Purpose |
|---|---|
| `scripts/odrive_can_drive.lua` | The driver. Copy to `APM/scripts/` on the flight controller's SD card. |
| `scripts/odrive_can_sniffer.lua` | Bench check. Shows ODrive heartbeats in the GCS messages. Run it on its own. |
| `params/odrive_rover.param` | CAN and scripting parameters. Load in Mission Planner, then reboot. |
| `odrive/odrive_setup.py` | Sets node IDs, CAN bit rate, heartbeat, watchdog and velocity mode on the ODrive. |
| `tests/` | `run_tests.py` runs the drive script against a mock of the ArduPilot API (`pip install lupa`). |

The scripts follow the structure of ArduPilot's `CAN_write.lua`, `CAN_read.lua` and
`CAN_MiniCheetah_drive.lua` examples, so they are GPLv3 like the originals.

## Setup

1. Calibrate both motors and encoders with `odrivetool` and set `pre_calibrated = True`.
2. Run `python3 odrive/odrive_setup.py`. Node 0 is axis0 (left), node 1 is axis1 (right).
3. Wire CAN H/L between the ODrive and the flight controller. Fit the 120 ohm termination
   jumper on the ODrive if it is at the end of the bus, and terminate the flight controller end too.
4. Load `params/odrive_rover.param`, reboot, and check `SERVO1_FUNCTION=73`, `SERVO3_FUNCTION=74`
   suit your Rover frame setup.
5. Put `odrive_can_sniffer.lua` in `APM/scripts/`, reboot, and confirm both nodes show up in the
   GCS messages with state 1 and error 0x0. Then swap it for `odrive_can_drive.lua`.

## First drive

- Wheels off the ground.
- `MAX_RPS` is 2.0 turns/s by default. Raise it only once direction and response are right.
- Right side is set to `sign = -1` in the `NODES` table, assuming mirrored motors. Change it if
  the wrong wheel reverses.
- Arm, give a little throttle, and check each side turns the right way.
- Pull the CAN cable while spinning. The script should report a lost heartbeat and ramp to
  zero, and the ODrive watchdog should stop the axes within its timeout (0.5 s by default).

## Behaviour

- Disarmed: both axes are sent zero velocity and set to idle (a few frames, then silent).
- Armed: waits for a heartbeat from every node, clears old errors, sets velocity/passthrough
  mode, then requests closed loop.
- Driving: 50 Hz velocity commands with a slew limit (`ACCEL_RPS2`). Any axis error, or a lost
  heartbeat, ramps both sides to zero until the next disarm and arm. Sending the velocity
  command also feeds the ODrive watchdog.

## What has and has not been checked

- Command IDs (0x07, 0x0B, 0x0D, 0x18, heartbeat 0x01) were checked against the ODrive CAN
  protocol documentation.
- Logic and frame contents were tested against a mock API (`tests/run_tests.py`, 21 checks).
- It has not been run on a flight controller or an ODrive. Two ArduPilot calls are untested on
  real hardware: `frame:id():toint()` and `string.pack`. If either errors, the script reports
  it in the GCS messages.
- `odrive_setup.py` tries both attribute spellings used across 0.5.x releases. Check the
  result in `odrivetool` if it complains.

## Correction to my earlier message

Clear_Errors is command 0x18, not 0x19 as I wrote before. 0x19 is Set_Linear_Count. The
scripts here use 0x18.
