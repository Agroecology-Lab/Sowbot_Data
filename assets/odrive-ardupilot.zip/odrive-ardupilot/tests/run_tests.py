#!/usr/bin/env python3
"""Run odrive_can_drive.lua against a mock of the ArduPilot scripting API (needs: pip install lupa)."""
import os
import struct
import sys

from lupa import LuaRuntime

HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT = os.path.join(HERE, "..", "scripts", "odrive_can_drive.lua")

failures = []


def check(name, cond, detail=""):
    print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else f"  [{detail}]"))
    if not cond:
        failures.append(name)


def fresh():
    lua = LuaRuntime(unpack_returned_tuples=True)
    lua.execute(open(os.path.join(HERE, "mock_ardupilot.lua")).read())
    fn, _delay = lua.execute(f'return dofile("{SCRIPT}")')
    g = lua.globals()
    state = {"fn": fn}

    def step(n=1):
        for _ in range(n):
            state["fn"], _ = state["fn"]()

    def frames():
        return [(int(f["id"]), [int(f["bytes"][i + 1]) for i in range(int(f["dlc"]))]) for f in g.sent.values()]

    def clear():
        lua.execute("sent = {}")

    return lua, g, step, frames, clear


def vel_frames(frames, node):
    out = []
    for fid, data in frames:
        if fid == (node << 5) | 0x0D:
            out.append(struct.unpack("<ff", bytes(data))[0])
    return out


# 1. no heartbeats: armed must not engage
lua, g, step, frames, clear = fresh()
lua.execute("armed = true")
step(5)
check("armed without heartbeats sends nothing", frames() == [], frames())
check("warns about missing heartbeat", any("no heartbeat" in t for t in g.texts.values()))

# 2. heartbeats ok: engage sequence and IDs
lua, g, step, frames, clear = fresh()
lua.execute("heartbeat(0,0,1); heartbeat(1,0,1)")
step(1)
lua.execute("armed = true")
step(1)
f = frames()
ids = [x[0] for x in f]
check("engage frame IDs for node 0", [0x0B, 0x0D, 0x07] == [i for i in ids if i < 32], ids)
check("engage frame IDs for node 1", [0x2B, 0x2D, 0x27] == [i for i in ids if i >= 32], ids)
modes = [d for i, d in f if i == 0x0B][0]
check("controller modes = velocity(2), passthrough(1)", struct.unpack("<ii", bytes(modes)) == (2, 1), modes)
state = [d for i, d in f if i == 0x07][0]
check("axis state = closed loop (8)", struct.unpack("<I", bytes(state))[0] == 8, state)

# 3. full throttle, slew limit and direction sign
clear()
lua.execute("outputs[73] = 1000; outputs[74] = 1000")
step(3)
l, r = vel_frames(frames(), 0), vel_frames(frames(), 1)
check("left ramps by 0.1 turns/s per 20 ms tick", all(abs(l[i] - 0.1 * (i + 1)) < 1e-5 for i in range(3)), l)
check("right is inverted (sign = -1)", all(abs(r[i] + 0.1 * (i + 1)) < 1e-5 for i in range(3)), r)
step(40)
l = vel_frames(frames(), 0)
check("left caps at MAX_RPS (2.0)", abs(max(l) - 2.0) < 1e-5, max(l))
check("Set_Input_Vel payload is 8 bytes", all(len(d) == 8 for i, d in frames() if i == 0x0D), "")

# 4. out-of-range output is clamped
lua.execute("outputs[73] = 5000")
clear(); step(2)
check("throttle > 1000 clamped", abs(max(vel_frames(frames(), 0)) - 2.0) < 1e-5, vel_frames(frames(), 0))

# 5. disarm: zero velocity then idle
clear()
lua.execute("armed = false")
step(1)
f = frames()
check("disarm sends zero velocity", vel_frames(f, 0) == [0.0] and vel_frames(f, 1) == [0.0], f)
idle = [d for i, d in f if i == 0x07]
check("disarm sets idle (1) on both axes", len(idle) == 1 and struct.unpack("<I", bytes(idle[0]))[0] == 1 or
      [struct.unpack("<I", bytes(d))[0] for d in idle] == [1], idle)
clear(); step(10)
check("stops repeating after STOP_REPEATS", len(frames()) <= 4 * 2 * 1 + 8, len(frames()))
clear(); step(5)
check("silent once settled", frames() == [], frames())

# 6. axis error while driving: both sides go to zero
lua, g, step, frames, clear = fresh()
lua.execute("heartbeat(0,0,1); heartbeat(1,0,1)")
step(1)
lua.execute("armed = true; outputs[73] = 1000; outputs[74] = 1000")
step(30)
lua.execute("heartbeat(0,0,8); heartbeat(1,0x40,1)")   # node 1 reports an error
clear(); step(40)
l, r = vel_frames(frames(), 0), vel_frames(frames(), 1)
check("fault on one axis ramps both to zero", abs(l[-1]) < 1e-6 and abs(r[-1]) < 1e-6, (l[-1], r[-1]))
check("fault is reported", any("error 0x40" in t for t in g.texts.values()), list(g.texts.values()))

# 7. stale error before arming: Clear_Errors (0x18) first, no engage
lua, g, step, frames, clear = fresh()
lua.execute("heartbeat(0,0x40,1); heartbeat(1,0,1)")
step(1)
lua.execute("armed = true")
step(1)
f = frames()
check("stale error triggers Clear_Errors on node 0", [i for i, _ in f] == [0x18], f)
check("no closed-loop request while error present", all(i != 0x07 for i, _ in f), f)

# 8. heartbeat loss while driving
lua, g, step, frames, clear = fresh()
lua.execute("heartbeat(0,0,1); heartbeat(1,0,1)")
step(1)
lua.execute("armed = true; outputs[73] = 1000; outputs[74] = 1000")
step(10)
clear(); step(120)    # no more heartbeats arrive
l = vel_frames(frames(), 0)
check("lost heartbeat ramps to zero", abs(l[-1]) < 1e-6, l[-1])
check("lost heartbeat is reported", any("lost heartbeat" in t for t in g.texts.values()))

print()
print("all tests passed" if not failures else f"{len(failures)} failed: {failures}")
sys.exit(1 if failures else 0)
