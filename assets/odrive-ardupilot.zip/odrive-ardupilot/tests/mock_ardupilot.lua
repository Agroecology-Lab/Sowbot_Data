-- Minimal stand-in for the ArduPilot scripting API, enough to run odrive_can_drive.lua off-vehicle.
sent = {}          -- every frame the script wrote: { id=, dlc=, bytes={} }
rx_queue = {}      -- frames the "ODrive" will deliver: { id=, bytes={} }
texts = {}         -- gcs:send_text log
armed = false
outputs = { [73] = 0, [74] = 0 }   -- SRV_Channels scaled output, -1000..1000

function uint32_t(n)
  return { n = n, toint = function(self) return self.n end }
end

function CANFrame()
  local f = { _id = uint32_t(0), _dlc = 0, _d = {} }
  function f:id(v) if v ~= nil then self._id = v else return self._id end end
  function f:dlc(v) if v ~= nil then self._dlc = v else return self._dlc end end
  function f:data(i, v) if v ~= nil then self._d[i] = v else return self._d[i] or 0 end end
  return f
end

local device = {}
function device:write_frame(msg, timeout)
  local bytes = {}
  for i = 0, msg:dlc() - 1 do bytes[#bytes + 1] = msg:data(i) end
  sent[#sent + 1] = { id = msg:id():toint(), dlc = msg:dlc(), bytes = bytes }
  return true
end
function device:read_frame()
  local item = table.remove(rx_queue, 1)
  if not item then return nil end
  local f = CANFrame()
  f:id(uint32_t(item.id))
  f:dlc(#item.bytes)
  for i, b in ipairs(item.bytes) do f:data(i - 1, b) end
  return f
end

CAN = { get_device = function(self, size) return device end }
arming = { is_armed = function(self) return armed end }
SRV_Channels = { get_output_scaled = function(self, fn) return outputs[fn] end }
gcs = { send_text = function(self, sev, text) texts[#texts + 1] = text end }

function heartbeat(node, err, state)
  rx_queue[#rx_queue + 1] = {
    id = (node << 5) | 0x01,
    bytes = { err & 0xFF, (err >> 8) & 0xFF, (err >> 16) & 0xFF, (err >> 24) & 0xFF, state, 0, 0, 0 },
  }
end
